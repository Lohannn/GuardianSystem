using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WaterLevelView : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private List<WaterLevelSlider> sliders;
    [SerializeField] private WaterLevelButtonView waterLevelButton;
    [SerializeField] private WaterLevelPresenter presenter;

    void Awake()
    {
        foreach (WaterLevelSlider slider in sliders)
        {
            slider.AddOnValueChanged(SetZoneLevelValue);
        }
    }

    private void SetZoneLevelValue(Zone zone, float newValue)
    {
        presenter.ChangeZoneLevel(zone, newValue);
    }

    public void UpdateSliders(Dictionary<Zone, float> zones)
    {
        foreach (Zone zone in zones.Keys)
        {
            WaterLevelSlider currentSlider = sliders.Find(slider => slider.SourceZone == zone);

            if (currentSlider == null)
            {
                Debug.LogWarning($"Cannot encounter a slider with the {zone} zone.");
                continue;
            }

            currentSlider.SetValue(zones[zone]);
        }

        CheckCrisisMode();
    }

    private void CheckCrisisMode()
    {
        foreach (WaterLevelSlider slider in sliders)
        {
            if (slider.inCrisisState)
            {
                waterLevelButton.SetWaterCrisis();
                return;
            }
        }

        waterLevelButton.RemoveWaterCrisis();
    }
}
